<div class="header col-sm-12">
			
	<!-- HEADER SECTION STARTS -->
		
		<div class="col-sm-12">
			
			<div class="header">
			
				<div class="col-sm-4">
			
				<div class=""></div>
				
			</div>
			
				<div class="col-sm-8">
			
				<div class="headerMenu">
					
					<ul>
						<a href="index.php"><li>Home</li>
						<a href="aboutUs.php"><li>About Us</li></a>
						<a href="login.php"><li>Login</li></a>
						<a href="contactUs.php"><li>Contact Us</li></a>
					</ul>
					
				</div>
			</div>
			
			
			</div> <!-- header -->
		
		</div> <!-- col-sm-12 -->
		
	<!-- HEADER SECTION ENDS -->
		
</div> 
				