<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css"/>
    <link rel="stylesheet" href="uttarakhand.css">
    <title>about</title>
</head>
<body>
    
    <header class="header"> 
        <img src="img/logo.jpg" alt="thi sis logo" class="logo">
           <nav class="navbar">
               <ul class="nav-list">
                  <li class="nav-link" > <a href="home.html"> HOME</a> </li>
                  <li class="nav-link"><a href="about.html">ABOUT US</a> </li>
                  <li class="nav-link"><a href="explore.html">EXPLORE</a> </li>
                  <li class="nav-link" > <a href="book.html" > BOOK </a> </li>
                  <li class="nav-link"><a href="contact.html"> CONTACT</a> </li>
                </ul>   
             </nav>
  
             <div class="mobil-nav-btn">
              <ion-icon name="menu-outline" class="mobile-nav-icon"></ion-icon>
              <ion-icon name="close-outline" class="mobile-nav-icon"></ion-icon>
        </header>




        <div class="about-header">
         <h1>ABOUT US </h1>
      </div>


<div class="about-container">
   <div class="adress">
      <div class="con">
         <h5> Almora tourism , 263601</h5>
         <p>uttarakhand, delhi</p>
     <br>
     <br>
     <br>
     

     <h5> +918077692820</h5>
    <p>Monday to saturday, 10AM TO 6PM</p>

     <br>
     <br>
     <br>

   <h5>gaurav.sharma12@gmail.com</h5>
   <p>Email us your query</p>
</div>
   <div class="image">
      <img src="img/gsk.jpg" alt="">
   </div>
   </div>

   <div class="other">
      
      
      <div class="content">
         <h3>why choose us?</h3>
         
        <span> Honest prices : </span> <p> we have the best prices for tours, and a huge selection of destinations will not leave indifferent even avid tourist.
      </p>
      <br>
      <br>
      
         <span> Reliable partners :</span> <p>We work with the best tour operators who over the years have proven their professionalism.
      </p>
      <br>
      <br>
      
         <span> Full Service :</span> <p> Everything that a tourist may need when going abroad, in addition to the ticket.
      </p>
      <br>
      <br>
      
         <span> Quality Guarantee : </span> <p>We do not have to worry about paperwork necessary documents.
      </p>
      <br>
      <br>
      
         <span> Full support :</span><p> contacting us, you get full support, from choosing the tour and ending with advice on what to take with you on a trip.
      </p>
      <br>
      <br>
      
        <span> Document processing : </span> <p> With us you won’t have to worry about processing the necessary documents.
      </p>
         <div class="icons-container">
            <div class="icons">
               <i class="fas fa-map"></i>
               <span>top destinations</span>
            </div>
            <div class="icons">
               <i class="fas fa-hand-holding-usd"></i>
               <span>affordable price</span>
            </div>
            <div class="icons">
               <i class="fas fa-headset"></i>
               <span>24/7 guide service</span>
            </div>
         </div>
      </div>
   </div>
</div>









        
                                         <!-- footer section starts  -->

<section class="footer">

    <div class="box-container">
  
      
       
       <div class="box">
          <!-- <h3>contact info</h3> -->
          <a href="#"> <i class="fas fa-phone"></i> +8077692820 </a>
          <a href="#"> <i class="fas fa-phone"></i> +8273972522 </a>
          <a href="#"> <i class="fas fa-envelope"></i> gaurav.sharma12@gmail.com </a>
          <a href="#"> <i class="fas fa-map"></i> Almora, tourism - 263601 </a>
       </div>
  
       <div class="box">
          <!-- <h3>follow us</h3> -->
          <a href="#"> <i class="fab fa-facebook-f"></i> facebook </a>
          <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
          <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
          <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
       </div>
    
       <div class="credit">
        <p>Created By <span>Mr. Gaurav Singh Karki</span> | All Rights Reserved! </p>
     </div>
    </div>
    
    
  
  </section>
  
  
  
  
                                                  <!-- footer section ends -->
                                                  
   <script
      type="module"
      src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"
    ></script>
    <script
      nomodule
      src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"
    ></script>

                <!-- swiper  -->
 <script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>
    </script>

<script src="uttarakhand.js"> </script>

</body>
</html>